var __esm = (fn, res, err) => () => {
  if (fn)
    try {
      res = fn(fn = 0);
    } catch (e) {
      err = [e];
    }
  if (err)
    throw err[0];
  return res;
};

// chimera/src/wasm/chimera.ts
function initChimera(source) {
  if (loading)
    return loading;
  loading = (async () => {
    let mod;
    if (source && typeof source !== "string")
      mod = await WebAssembly.compile(source);
    else {
      const url = source ?? (await import("./chimera.wasm?url")).default;
      const res = await fetch(url);
      if (!res.ok)
        throw new Error(`engine: ${url}: HTTP ${res.status}`);
      mod = await WebAssembly.compile(await res.arrayBuffer());
    }
    if (WebAssembly.Module.imports(mod).length)
      throw new Error("engine: the wasm module must not have imports");
    exports = (await WebAssembly.instantiate(mod, {})).exports;
    module = mod;
  })();
  loading.catch(() => loading = null);
  return loading;
}
function chimeraModule() {
  if (!module)
    throw new Error("engine not loaded (await initChimera())");
  return module;
}
function x() {
  if (!exports)
    throw new Error("engine not loaded (await initChimera())");
  return exports;
}
function call(fn, args = {}) {
  const e = x();
  const bytes = enc.encode(JSON.stringify({ fn, ...args }));
  const p = e.chimera_alloc(bytes.length);
  new Uint8Array(e.memory.buffer, p, bytes.length).set(bytes);
  const status = e.chimera_call(p, bytes.length);
  e.chimera_free(p, bytes.length);
  const out = dec.decode(new Uint8Array(e.memory.buffer, e.chimera_result_ptr(), e.chimera_result_len()));
  const v = JSON.parse(out);
  if (status !== 0)
    throw new Error(`engine ${fn}: ${v.error}`);
  return v;
}
var module = null, exports = null, loading = null, enc, dec;
var init_chimera = __esm(() => {
  enc = new TextEncoder;
  dec = new TextDecoder;
});

// chimera/src/ui/creatureVisuals.ts
var CREATURE_VISUALS;
var init_creatureVisuals = __esm(() => {
  CREATURE_VISUALS = {
    songbird: {
      view: { x0: -4, x1: 14, y0: -6, y1: 8 },
      silhouette: [[-3.2, -1.2], [-1.6, -3.4], [1.6, -4.6], [5.2, -4.4], [7.8, -2.6], [9, -0.4], [9.6, 1.8], [10.4, 2.4], [12.8, 2.6], [10.6, 3], [9.8, 3.6], [9.2, 4.6], [7.6, 5.2], [6, 4.6], [4.2, 2.8], [2, 2], [-0.2, 1.6], [-3.6, 1.4], [-3.4, 0.2]],
      parts: [{ shade: 0.2, pts: [[8.6, 4], [8.95, 4.3], [9.2, 4], [8.95, 3.7]] }],
      tubes: [
        { tube: "bronchusL", path: [[3.4, -1.9], [4.4, -1.4]], label: "Left bronchus", inView: false },
        { tube: "bronchusR", path: [[3.4, -0.9], [4.4, -1.2]], label: "Right bronchus", inView: false },
        { tube: "trachea", path: [[4.4, -1.3], [5.6, -0.4], [6.8, 0.8], [7.8, 1.9], [8.6, 2.5]], label: "Trachea" },
        { tube: "beak", path: [[9.4, 2.75], [10.6, 2.75], [12.4, 2.7]], label: "Beak" }
      ],
      tubeScale: 1.6,
      sources: [{ key: "left", at: [4.2, -1.6], label: "Left voice" }, { key: "right", at: [4.2, -1], label: "Right voice" }]
    },
    seal: {
      view: { x0: -60, x1: 60, y0: -30, y1: 30 },
      silhouette: [[-58, -2], [-50, -8], [-30, -14], [-5, -16], [20, -14], [38, -10], [48, -6], [55, -3], [58, 1], [56, 5], [50, 8], [42, 10], [30, 11], [10, 13], [-15, 13], [-35, 10], [-50, 6], [-56, 3], [-62, 8], [-64, 4], [-60, 0], [-64, -4], [-62, -8]],
      parts: [{ shade: 0.15, pts: [[47, 4], [48.5, 5], [50, 4], [48.5, 3]] }],
      tubes: [
        { tube: "trachea", path: [[8, -4], [20, -3], [30, -2]], label: "Trachea" },
        { tube: "pharynx", path: [[30, -2], [38, 0], [44, 1.5]], label: "Pharynx" },
        { tube: "oral", path: [[44, 1.5], [50, 0.5], [57, -0.5]], label: "Mouth" }
      ],
      tubeScale: 1.3,
      sources: [{ key: "glottis", at: [30, -2], label: "Larynx" }]
    },
    alligator: {
      view: { x0: -120, x1: 120, y0: -40, y1: 40 },
      silhouette: [[-118, 2], [-90, -4], [-60, -8], [-30, -14], [0, -16], [30, -14], [50, -10], [70, -8], [95, -5], [114, -3], [118, 0], [115, 3], [98, 5], [75, 7], [52, 9], [40, 12], [20, 14], [-10, 14], [-40, 11], [-70, 7], [-100, 4]],
      parts: [{ shade: 0.15, pts: [[54, 9], [56, 11], [58, 9], [56, 8]] }],
      tubes: [
        { tube: "trachea", path: [[0, -6], [18, -5], [36, -4]], label: "Trachea" },
        { tube: "pharynx", path: [[36, -4], [46, -2], [54, 0]], label: "Pharynx" },
        { tube: "oral", path: [[54, 0], [80, -1], [112, -1]], label: "Mouth" },
        { tube: "nasal", path: [[54, 2], [80, 4], [113, 2]], label: "Nostrils" }
      ],
      tubeScale: 1.05,
      sources: [{ key: "glottis", at: [36, -4], label: "Larynx" }]
    },
    elephant: {
      view: { x0: -170, x1: 170, y0: -170, y1: 130 },
      silhouette: [[-160, 20], [-150, 70], [-110, 105], [-40, 118], [30, 115], [70, 100], [95, 112], [120, 108], [140, 85], [148, 55], [146, 25], [140, 5], [132, -20], [128, -60], [122, -110], [118, -150], [108, -152], [112, -100], [110, -50], [104, -20], [96, -5], [80, 0], [70, -10], [66, -90], [40, -95], [44, -30], [-90, -30], [-95, -95], [-125, -95], [-122, -10], [-150, -5]],
      parts: [{ shade: 0.15, pts: [[118, 62], [122, 66], [126, 62], [122, 58]] }, { shade: 0.62, pts: [[70, 100], [40, 60], [55, 25], [85, 40], [95, 80]] }],
      tubes: [
        { tube: "trachea", path: [[40, 20], [70, 30], [95, 38]], label: "Trachea" },
        { tube: "pharynx", path: [[95, 38], [112, 50], [124, 58]], label: "Pharynx" },
        { tube: "oral", path: [[124, 58], [130, 42], [134, 30]], label: "Mouth" },
        { tube: "trunk", path: [[136, 70], [142, 40], [136, 0], [128, -50], [120, -100], [113, -148]], label: "Trunk" }
      ],
      tubeScale: 3,
      sources: [{ key: "glottis", at: [95, 38], label: "Vocal folds" }, { key: "lips", at: [136, 70], label: "Trunk valve" }]
    }
  };
});

// chimera/src/wasm/engine.ts
class EnglishG2P {
  loading = null;
  isLoaded = false;
  get loaded() {
    return this.isLoaded;
  }
  load(url = "/data/cmudict.txt.gz") {
    if (this.isLoaded)
      return Promise.resolve();
    if (this.loading)
      return this.loading;
    this.loading = fetchGzText(url).then((text) => this.setDictionaryText(text), (e) => {
      this.loading = null;
      throw e;
    });
    return this.loading;
  }
  setDictionaryText(text) {
    call("g2pLoad", { text });
    this.isLoaded = true;
  }
  toPhrases(text) {
    return call("g2pPhrases", { text });
  }
  word(w, reduce = true) {
    return call("g2pWord", { word: w, reduce });
  }
}
async function fetchGzText(url) {
  const res = await fetch(url);
  if (!res.ok)
    throw new Error(`${url}: ${res.status}`);
  const bytes = new Uint8Array(await res.arrayBuffer());
  if (bytes[0] === 31 && bytes[1] === 139) {
    const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream("gzip"));
    return new Response(stream).text();
  }
  return new TextDecoder().decode(bytes);
}
function lyricsToSyllables(text, lang = "en") {
  return call("lyricsToSyllables", { text, lang });
}
function planSong(notes, options) {
  return call("planSong", { notes, options });
}
var CATALOG, NEUTRAL, BODY_MALE, BODY_FEMALE, BODY_CHILD, ARTIC_KEYS, ARTIC_SPECS, DEFAULT_SOURCE, EXHALE_LABEL, BASS_NOTE, BEAT_SOUNDS, BEAT_PRESETS, VOWEL_TARGETS, DEMO_SONGS, VOWELS, CREATURES;
var init_engine = __esm(() => {
  init_chimera();
  init_creatureVisuals();
  CATALOG = call("catalog");
  NEUTRAL = CATALOG.neutral;
  BODY_MALE = CATALOG.bodies.male;
  BODY_FEMALE = CATALOG.bodies.female;
  BODY_CHILD = CATALOG.bodies.child;
  ARTIC_KEYS = CATALOG.articKeys;
  ARTIC_SPECS = CATALOG.articSpecs;
  DEFAULT_SOURCE = CATALOG.defaultSource;
  EXHALE_LABEL = CATALOG.exhaleLabel;
  BASS_NOTE = CATALOG.bassNote;
  BEAT_SOUNDS = CATALOG.beatSounds;
  BEAT_PRESETS = CATALOG.beatPresets;
  VOWEL_TARGETS = CATALOG.vowelTargets;
  DEMO_SONGS = CATALOG.demoSongs;
  VOWELS = CATALOG.vowels;
  CREATURES = CATALOG.creatures.map((c) => ({ ...c, visual: CREATURE_VISUALS[c.id] }));
});

// out/chimera-handoff/render.ts
init_chimera();
import { readFileSync as readFileSync2 } from "node:fs";
import { gunzipSync } from "node:zlib";

// chimera/src/wasm/wire.ts
var GESTURE_RECORD = 272;
var CONTROL_KEYS = [
  "jaw",
  "tbX",
  "tbY",
  "ttX",
  "ttY",
  "ttCurl",
  "root",
  "lipAp",
  "lipProt",
  "lipWidth",
  "labiodental",
  "velum",
  "larynx",
  "epilarynx",
  "ventricular",
  "lateral",
  "dorsum",
  "abduction",
  "closure",
  "breath",
  "f0",
  "vibrato"
];
var KEY_INDEX = Object.fromEntries(CONTROL_KEYS.map((k, i) => [k, i]));
var LABEL_CAP = 24;
function utf8(s) {
  const out = [];
  for (const ch of s) {
    const c = ch.codePointAt(0);
    if (c < 128)
      out.push(c);
    else if (c < 2048)
      out.push(192 | c >> 6, 128 | c & 63);
    else if (c < 65536)
      out.push(224 | c >> 12, 128 | c >> 6 & 63, 128 | c & 63);
    else
      out.push(240 | c >> 18, 128 | c >> 12 & 63, 128 | c >> 6 & 63, 128 | c & 63);
  }
  return out;
}
function writeGestures(buf, at, gestures, max) {
  const n = Math.min(gestures.length, max);
  const dv = new DataView(buf, at, n * GESTURE_RECORD);
  const bytes = new Uint8Array(buf, at, n * GESTURE_RECORD);
  for (let i = 0;i < n; i++) {
    const g = gestures[i];
    const o = i * GESTURE_RECORD;
    const head = [g.t0, g.t1, g.rampIn, g.rampOut, g.strength, g.speed ?? NaN, g.releaseHold ?? NaN, g.tag ?? NaN];
    for (let j = 0;j < 8; j++)
      dv.setFloat64(o + j * 8, head[j], true);
    for (let k = 0;k < CONTROL_KEYS.length; k++)
      dv.setFloat64(o + 64 + k * 8, NaN, true);
    for (const [key, value] of Object.entries(g.targets)) {
      const k = KEY_INDEX[key];
      if (k !== undefined && value !== undefined)
        dv.setFloat64(o + 64 + k * 8, value, true);
    }
    if (g.label === undefined)
      bytes[o + 240] = 255;
    else {
      let b = utf8(g.label);
      if (b.length > LABEL_CAP) {
        let n = LABEL_CAP;
        while (n > 0 && (b[n] & 192) === 128)
          n--;
        b = b.slice(0, n);
      }
      bytes[o + 240] = b.length;
      bytes.set(b, o + 241);
    }
  }
  return n;
}

// chimera/tools/lib/wav.ts
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { dirname } from "node:path";
function writeWav(path, channels, sampleRate) {
  const nCh = channels.length;
  const n = channels[0].length;
  const bytesPerSample = 2;
  const dataBytes = n * nCh * bytesPerSample;
  const buf = Buffer.alloc(44 + dataBytes);
  buf.write("RIFF", 0);
  buf.writeUInt32LE(36 + dataBytes, 4);
  buf.write("WAVE", 8);
  buf.write("fmt ", 12);
  buf.writeUInt32LE(16, 16);
  buf.writeUInt16LE(1, 20);
  buf.writeUInt16LE(nCh, 22);
  buf.writeUInt32LE(sampleRate, 24);
  buf.writeUInt32LE(sampleRate * nCh * bytesPerSample, 28);
  buf.writeUInt16LE(nCh * bytesPerSample, 32);
  buf.writeUInt16LE(16, 34);
  buf.write("data", 36);
  buf.writeUInt32LE(dataBytes, 40);
  let o = 44;
  for (let i = 0;i < n; i++) {
    for (let c = 0;c < nCh; c++) {
      let v = channels[c][i];
      if (!Number.isFinite(v))
        v = 0;
      v = Math.max(-1, Math.min(1, v));
      buf.writeInt16LE(Math.round(v * 32767), o);
      o += 2;
    }
  }
  mkdirSync(dirname(path), { recursive: true });
  writeFileSync(path, buf);
}

// out/chimera-handoff/render.ts
var [input = "score.json", output = "neon.wav"] = process.argv.slice(2);
var score = JSON.parse(readFileSync2(input, "utf8"));
var rate = 48000;
var wasm = readFileSync2(new URL("./src/audio/moppet.wasm", import.meta.url));
await initChimera(wasm);
await Promise.resolve().then(() => init_engine());
var dictionary = readFileSync2(new URL("./chimera/public/data/cmudict.txt.gz", import.meta.url));
new EnglishG2P().setDictionaryText(gunzipSync(dictionary).toString());
var gestures = [];
var last = 0;
for (const phrase of score.phrases) {
  const syllables = lyricsToSyllables(phrase.lyrics);
  if (syllables.length !== phrase.notes.length) {
    throw new Error(`"${phrase.lyrics}" has ${syllables.length} syllables for ${phrase.notes.length} notes.`);
  }
  const plan = planSong(phrase.notes.map((note, index) => ({ ...note, syl: syllables[index] })), {
    body: score.body,
    bpm: score.bpm,
    t0: score.leadIn + phrase.beat * 60 / score.bpm,
    vibrato: score.vibrato
  });
  gestures.push(...plan.gestures);
  last = Math.max(last, plan.end);
}
if (gestures.length > 4000)
  throw new Error("Split this score into shorter takes to fit one native scheduling call.");
var engine = new WebAssembly.Instance(chimeraModule(), {}).exports;
var handle = engine.engine_new(rate);
var frames = Math.ceil(Math.max(score.leadIn + score.beats * 60 / score.bpm, last) * rate + score.tail * rate);
var samples = new Float32Array(frames);
try {
  engine.engine_set_body(handle, score.body.female, score.body.child);
  const count = writeGestures(engine.memory.buffer, engine.engine_records(handle), gestures, 4000);
  engine.engine_schedule(handle, count, 0, 1);
  for (let offset = 0;offset < samples.length; offset += 128) {
    const length = Math.min(128, samples.length - offset);
    const pointer = engine.engine_render(handle, length);
    samples.set(new Float32Array(engine.memory.buffer, pointer, length), offset);
  }
} finally {
  engine.engine_free(handle);
}
writeWav(output, [samples], rate);
console.log(`Wrote ${output} (${(frames / rate).toFixed(2)} s, ${rate} Hz, mono)`);

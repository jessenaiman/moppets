# CHIMERA handoff for Lights Wake Up

Moppets revision `ebcad05`. Upstream CHIMERA revision `7c0f722e6a375f0acae543364565741d58c100c9`.

From the extracted directory, run:

```sh
node render-neon.mjs score.json neon.wav
```

The runner uses Node 18 and the bundled English dictionary. It creates mono 48 kHz vocals from the written phrases using the native CHIMERA engine. The example uses Neon's body and vibrato with the engine's remaining source and articulation defaults. Edit `score.json` to write new phrases. Each entry specifies its start in quarter-note beats, its lyrics, and one MIDI pitch and beat duration per syllable. The example fits in one native call, which accepts at most 4,000 gestures.

`lights-wake-up-band.mid` has the square lead, bass and drums. `lights-wake-up-score.mid` also includes MIDI notes for Neon's written harmony. Both MIDI files start at score beat zero. Offset them by the `leadIn` in `score.json` when mixing with the WAV.

`src/audio/moppet.wasm` and `chimera/src/wasm/chimera.wasm` contain the same pinned upstream WASM. The renderer uses the `engine_*` exports. The source snapshot is under `chimera/src/`. Its bundled Node runner is ready to use without transpiling TypeScript or installing dependencies.
